import { Park } from './park';

describe('Park', () => {
  it('should create an instance', () => {
    expect(new Park()).toBeTruthy();
  });
});
