export interface Park {
    titre:string;
    capacite:number;
    adresse:string;
}
