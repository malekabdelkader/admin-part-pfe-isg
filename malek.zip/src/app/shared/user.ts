export interface User{
    nom: string;
    prenom: string;
    telephone: number;
    email: string;
    password: string;   
}
